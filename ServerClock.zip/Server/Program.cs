﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ServerClock
{
    internal class Program
    {
        static void Main(string[] args)
        {
            UdpClient server = new UdpClient(12345);
            IPEndPoint remoteEp = new IPEndPoint(IPAddress.Any, 0);
            Console.WriteLine("Server Clock started...");
            while (true) 
            {
                byte[] receiveBytes = server.Receive(ref remoteEp);
                string request = Encoding.UTF8.GetString(receiveBytes);
                Console.WriteLine("Received request from client: "+request);
                if (request == "Request for time")
                {
                    string currentTime = DateTime.Now.ToString();
                    byte[] sendBytes = Encoding.UTF8.GetBytes(currentTime);
                    server.Send(sendBytes, sendBytes.Length, remoteEp);
                }
                else
                {
                    Console.WriteLine("Invalid command");
                }
                Thread.Sleep(1000);
            }
        }
    }
}
