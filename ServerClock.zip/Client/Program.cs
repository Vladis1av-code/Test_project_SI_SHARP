﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Client
{
    internal class Program
    {
        static void Main(string[] args)
        {
            UdpClient client = new UdpClient();
            IPEndPoint remoteEp = new IPEndPoint(IPAddress.Parse("213.109.81.253"), 12345);
            try
            {
                while (true)
                {
                    byte[] requestBytes = Encoding.ASCII.GetBytes("Request for time");
                    client.Send(requestBytes, requestBytes.Length, remoteEp);
                    byte[] receiveBytes = client.Receive(ref remoteEp);
                    string currentTime = Encoding.UTF8.GetString(receiveBytes);
                    Console.WriteLine("Time from server: " + currentTime);
                    Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                client.Close();
            }
        }
    }
}
