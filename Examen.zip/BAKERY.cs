﻿using System.Linq;
using System.IO;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Diagnostics.Metrics;
using System;
using System.Threading;
namespace ConsoleApp14
{
    class Program
    {
        private static object lockobj = new object(); // Объект блокировки
        private static int counter = 0; // Счетчик посетителей
        private static int nextId = 1; // ID следующего посетителя

        public static void BAKERY()
        {
            Monitor.Enter(lockobj); // Заходит в блок
            try
            {
                int id = nextId++; // Получение ID
                counter++; // Приходит клиент
                Console.WriteLine("______________________________________________");
                Console.WriteLine( "Клиент {0} (ID: {1}) зашел в пекарню", id, id); // ID  1 пользователя а потом 2 пользователя
                Console.WriteLine("______________________________________________");
                Console.WriteLine( "Клиент {0} делает заказ", id);
                Console.WriteLine("______________________________________________");

                Thread.Sleep(2000); //  приготовления
                Console.WriteLine( "Клиент {0} получил заказ", id);
                Console.WriteLine("______________________________________________");


                if (IsClientLeaving(id))
                {
                    Console.WriteLine("______________________________________________");
                    Console.WriteLine( "Клиент {0} покинул пекарню",  id);//проверка ухода
                    Console.WriteLine("______________________________________________");
                }
            }
            finally
            {
                Monitor.Exit(lockobj); // Пекарь выходит из блока
            }
        }
     
        private static bool IsClientLeaving(int id)
        {
            return false; // Временная заглушка
        }

        static void Main(string[] args)
        {
            Thread newThread = new Thread(PotocMain); // Поток 1
            Thread newPotoc = new Thread(NewMainPotoc); // Поток 2
            newThread.Start();//Начало
            newPotoc.Start();

            newThread.Join();//Конец
            newPotoc.Join();

            Console.WriteLine("______________________________________________");
            Console.WriteLine( "Программа завершена.");
            Console.WriteLine("______________________________________________");
        }
        static void PotocMain()
        {
            Console.WriteLine("______________________________________________");
            Console.WriteLine("Поток 1 начал работу");
            Console.WriteLine("______________________________________________");
            BAKERY();//вызывает public Bakery
            Console.WriteLine("______________________________________________");
            Console.WriteLine( "Поток 1 завершил работу");
            Console.WriteLine("______________________________________________");
        }
        static void NewMainPotoc()
        {
            Console.WriteLine("______________________________________________");
            Console.WriteLine( "Поток 2 начал работу");
            Console.WriteLine("______________________________________________");
            BAKERY();
            Console.WriteLine("______________________________________________");
            Console.WriteLine("Поток 2 завершил работу");
            Console.WriteLine("______________________________________________");
        }
    }

}
