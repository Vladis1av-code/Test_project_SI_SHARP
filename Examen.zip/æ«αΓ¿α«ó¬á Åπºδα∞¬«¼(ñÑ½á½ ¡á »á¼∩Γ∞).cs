﻿using System;
namespace Sort
{
     class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 13, 19, 15, 16, };
            Console.WriteLine("До сортирование пузырьком:"+arr);
            Sorting(arr);
        }
        static void Sorting(int[] arr)
        {
            bool a;
            for(int j=0; j< arr.Length-int-1; j++)
            {
                if (arr[j] > arr[j+1])
                {
                    int t = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = t;
                    a = true;
                }
            }
            Console.WriteLine(arr[j+1]=t);
        }
    }
}
