SELECT TOP (1000) [id_user]
      ,[login_user]
      ,[password_user]
  FROM [Planeta].[dbo].[register]
