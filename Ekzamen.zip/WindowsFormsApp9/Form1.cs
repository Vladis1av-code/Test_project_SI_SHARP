﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Net;
using System.IO;
using System.Windows.Controls;
using System.Security.Cryptography.X509Certificates;
using System.Data.SqlClient;
using System.Security.Policy;
using System.Diagnostics.Eventing.Reader;
using System.Drawing.Text;
using System.Diagnostics;
namespace WindowsFormsApp9
{
    public partial class Form1 : Form
    {
       

        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)//Начинает поиск по клику
        {
            string url = textBox1.Text;
           


            if (Uri.IsWellFormedUriString(url, UriKind.Absolute))
            {
                Uri uri = new Uri(url);

                // Открыть Forma 3 и отобразить страницу
                Form3 form3 = new Form3(uri, url);
                form3.Show();
            }
            else
            {
                MessageBox.Show("Неверный URL-адрес");
            }

           

        }

        private void pictureBox1_Click(object sender, EventArgs e)//Form 2
        {
            Form2 form2 = new Form2();
            this.Hide();
            form2.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)//Form 3
        {
            Form3 form3=new Form3();
            this.Hide();
            form3.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)//Form 4
        {
            Form4 form4 = new Form4();
            this.Hide();
            form4.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)//Поисковая система основная
        {
           

        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)//Text Google
        {
            Form2 form2=new Form2();
            this.Hide();
            form2.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)//Text Opera
        {
            Form3 form3 = new Form3();
            this.Hide();
            form3.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)//Text Teams
        {
           Form4 form4 = new Form4();
            this.Hide();
            form4.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)//Значок проги 
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)//кубик
        {
            Extension extension = new Extension();
            extension.Show();
        }

        private void pictureBox6_Click(object sender, EventArgs e)//Любимый сайт
        {
            Form5 form5 = new Form5();  
            form5.Show();
        }

        private void pictureBox7_Click(object sender, EventArgs e)//Загрузки
        {
            Download download = new Download();
            download.Show();
        }

        private void pictureBox8_Click(object sender, EventArgs e)//Камера
        {
           
        }

        private void pictureBox9_Click(object sender, EventArgs e)//Пользователь
        {
          
        }

        private void pictureBox10_Click(object sender, EventArgs e)//Перезагрузка
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void pictureBox11_Click(object sender, EventArgs e)//Настройка
        {
            Easy_setup easy_Setup = new Easy_setup();
            easy_Setup.Show();
        }

        private void pictureBox12_Click(object sender, EventArgs e)//Вернуться на прошлую форму
        {
           Form2 form2 = new Form2();
            this.Hide();
            form2.Show();

        }

        private void pictureBox13_Click(object sender, EventArgs e)//Возращает закрытую форму
        {
            Form2 form2=new Form2(this);
            this.Hide();
            form2.Show();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)//Поисковая система
        {

        }

        private void pictureBox14_Click(object sender, EventArgs e)//Защита сайта 
        {
            _1 _1 = new _1();
            _1.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

   
}
