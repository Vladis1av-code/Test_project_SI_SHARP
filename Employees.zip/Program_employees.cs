﻿ using System.IO;
using System;

namespace ConsoleApp31
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Меню");
            Console.WriteLine("__________________________________________");
            Console.WriteLine("1.Добавить сотрудника");
            Console.WriteLine("2.Удалить сотрудника");
            Console.WriteLine("3.Изменить данные про сотрудника");
            Console.WriteLine("4.Поиск сотрудников за параметрами");
            Console.WriteLine("5.Сортировка сотрудников за параметрами");
            Console.WriteLine("6.Выход");
            Console.WriteLine("__________________________________________");
            Console.Write("Введите цифру:");
            string choice= Console.ReadLine();

            if(choice =="1")
            {           
                Console.WriteLine("Введите Ф.И.О:");
                string print_name = Console.ReadLine();

                Console.WriteLine("Введите должность:");
                string print_post= Console.ReadLine();

                Console.WriteLine("Введите зарплату сотрудника:");
                string print_money= Console.ReadLine();

                Console.WriteLine("Введите корпоративную почту:");
                string print_email= Console.ReadLine();

                List<string> employees=new List<string>();//создаем список для хранение инфы
            
                employees.Insert(0,"Ф.И.О сотрудника:" + " " +print_name +" "+ "Должность:" + " " + print_post + " " +  "Зарплата сотрудника: " + " "+ print_money + " " + "Корпоративная почта:" + " "+ print_email);
                employees.Insert(1,"Ф.И.О сотрудника:" + " " + "Жирнов Константин Констянтинович" + " " + "Должность:" + "" + "Frontend-разработчик" + "" + "Зарплата сотрудника:" + "25000грн " + "Корпоративная почта:" + "pv178fh89@elitex.com");
                foreach(string employee in employees)
                {
                    Console.WriteLine("________________________________________________________________________");
                    Console.WriteLine(employee);
                    Console.WriteLine("________________________________________________________________________");
                }
                Console.ReadLine();
            }



            else if(choice =="2")
            {
                List<string> employees = new List<string>();//создаем список для хранение инфы
                Console.WriteLine("Введите id сотрудника:");
               int delete_employees=int.Parse(Console.ReadLine());

                employees.Insert( 0,"Ф.И.О сотрудника:" + " " + "Жирнов Константин Констянтинович" + " " + "Должность:" + "" + "Frontend-разработчик" + "" + "Зарплата сотрудника:" + "25000грн " + "Корпоративная почта:" + "pv178fh89@elitex.com");

                employees.Insert(1, "Ф.И.О сотрудника:" + " " + "" + " " + "Должность:" + "" + "Frontend-разработчик" + "" + "Зарплата сотрудника:" + "25000грн " + "Корпоративная почта:" + "pv178fh89@elitex.com");
                employees.Remove(employees[delete_employees]);
                foreach (string employee in employees)
                {
                    Console.WriteLine("Осталось сотрудников:");
                    Console.WriteLine("________________________________________________________________________");                 
                    Console.WriteLine(employee);
                    Console.WriteLine("________________________________________________________________________");
                }
              
            }





            else if(choice =="3")
            {
                Console.WriteLine("Введите новое Ф.И.О:");
                string print_name = Console.ReadLine();

                Console.WriteLine("Введите новую должность:");
                string print_post = Console.ReadLine();

                Console.WriteLine("Введите новою зарплату сотрудника:");
                string print_money = Console.ReadLine();

                Console.WriteLine("Введите новую корпоративную почту:");
                string print_email = Console.ReadLine();

                List<string> employees = new List<string>();//создаем список для хранение инфы

                employees.Insert(0, "Ф.И.О сотрудника:" + " " + print_name + " " + "Должность:" + " " + print_post + " " + "Зарплата сотрудника: " + " " + print_money + " " + "Корпоративная почта:" + " " + print_email);
                employees.Insert(1, "Ф.И.О сотрудника:" + " " + "Жирнов Константин Констянтинович" + " " + "Должность:" + "" + "Frontend-разработчик" + "" + "Зарплата сотрудника:" + "25000грн " + "Корпоративная почта:" + "pv178fh89@elitex.com");
                foreach (string employee in employees)
                {
                    Console.WriteLine("________________________________________________________________________");
                    Console.WriteLine(employee);
                    Console.WriteLine("________________________________________________________________________");
                }
            }




            else if(choice =="4")
            {
                Console.WriteLine("Меню");
                Console.WriteLine("1.Поиск по id");
                Console.WriteLine("2.Поиск по Ф.И.О");
               string choice_4= Console.ReadLine();
                if (choice_4 == "1")
                {
                    Console.WriteLine("Введите id сотрудника:");
                    string choice_id = Console.ReadLine();

                   
                    List<string> employees = new List<string>()
{
  "ID: 1 Ф.И.О сотрудника: Жирнов Константин Констянтинович Должность: Frontend-разработчик Зарплата сотрудника: 25000грн Корпоративная почта: pv178fh89@elitex.com",
  "ID: 2 Ф.И.О сотрудника: Иванов Иван Констянтинович Должность: Frontend-разработчик Зарплата сотрудника: 25000грн Корпоративная почта: pv178fh89@elitex.com"
};

                    // Поиск по ID
                    int index = employees.FindIndex(x => x.Contains("ID: " + choice_id));

                    // Вывод информации
                    if (index >= 0)
                    {
                        Console.WriteLine("________________________________________________________________________");
                        Console.WriteLine("Сотрудник найден:");
                        Console.WriteLine(employees[index]);
                        Console.WriteLine("________________________________________________________________________");
                    }
                    else
                    {
                        Console.WriteLine("________________________________________________________________________");
                        Console.WriteLine("Сотрудник с ID " + choice_id + " не найден.");
                        Console.WriteLine("________________________________________________________________________");
                    }
                }




                    
                else if(choice_4=="2")
                {
                    Console.WriteLine("Введите Ф.И.О сотрудника:");
                    string choice_name= Console.ReadLine();

                    List<string> employees = new List<string>()
{
  "Ф.И.О сотрудника:" + " " + "Жирнов Константин Констянтинович" + " " + "Должность:" + "" + "Frontend-разработчик" + "" + "Зарплата сотрудника:" + "25000грн " + "Корпоративная почта:" + "pv178fh89@elitex.com",
  "Ф.И.О сотрудника:" + " " + "Иванов Иван Константинович" + " " + "Должность:" + "" + "Frontend-разработчик" + "" + "Зарплата сотрудника:" + "25000грн " + "Корпоративная почта:" + "pv178fh89@elitex.com",
};

                    string name =choice_name ;

                    int index = employees.FindIndex(x => x.Contains("Ф.И.О сотрудника: " + name));

                    if (index >= 0)
                    {
                        Console.WriteLine("________________________________________________________________________");
                        Console.WriteLine("Сотрудник найден: " + employees[index]);
                        Console.WriteLine("________________________________________________________________________");
                    }
                    else
                    {
                        Console.WriteLine("________________________________________________________________________");
                        Console.WriteLine("Сотрудник не найден.");
                        Console.WriteLine("________________________________________________________________________");
                    }
                }


            }





            else if(choice =="5")
            {
                Console.WriteLine("Меню");
                Console.WriteLine("1.Сортировка сотрудников по алфавиту");
                Console.WriteLine("2.Сортировка сотрудников по айди");
                Console.Write("Введите цифру:");
                string print= Console.ReadLine();
                if (print == "1")
                {
                    List<string> employees = new List<string>();

                    employees.Insert(0, "Ф.И.О сотрудника:" + " " + "Жирнов Константин Констянтинович" + " " + "Должность:" + "" + "Frontend-разработчик" + "" + "Зарплата сотрудника:" + "25000грн " + "Корпоративная почта:" + "pv178fh89@elitex.com");
                    employees.Insert(1, "Ф.И.О сотрудника:" + " " + "Ващенко Максим Игорович " + " " + "Должность:" + " " + "Backend-разработчик" + "" + "Зарплата сотрудника:" + "60000грн" + "Корпоративная почта:" + "pv1765fh89@elitex.com ");

                    employees.Sort();//Сортировка по алфавиту
                    foreach (string employee in employees)
                    {
                        Console.WriteLine("________________________________________________________________________");
                        Console.WriteLine(employee);
                        Console.WriteLine("________________________________________________________________________");
                    }
                }
                else if (print == "2")
                {
                    int ExtractID(string str)
                    {
                        int index = str.IndexOf(':');
                        if (index > 0)
                        {
                            string idStr = str.Substring(0, index);
                            return int.Parse(idStr.Substring(2));
                        }
                        return -1; // Ошибка, если ID не найден
                    } 

                    int CompareIDs(string str1, string str2)
                    {
                        // Извлеките ID из строк
                        int id1 = ExtractID(str1);
                        int id2 = ExtractID(str2);

                        // Сравните ID
                        return id1.CompareTo(id2);
                    }

                    List<string> strings = new List<string>() { "ID1: \"Ф.И.О сотрудника:\" + \" \" + \"Жирнов Константин Констянтинович\" + \" \" + \"Должность:\" + \"\" + \"Frontend-разработчик\" + \"\" + \"Зарплата сотрудника:\" + \"25000грн \" + \"Корпоративная почта:\" + \"pv178fh89@elitex.com\"",
                        "ID2: \"Ф.И.О сотрудника:\" + \" \" + \"Ващенко Максим Игорович \" + \" \" + \"Должность:\" + \" \" + \"Backend-разработчик\" + \"\" + \"Зарплата сотрудника:\" + \"60000грн\" + \"Корпоративная почта:\" + \"pv1765fh89@elitex.com \"" };

                    strings.Sort(CompareIDs);

                    foreach (string str in strings)
                    {
                        Console.WriteLine(str);
                    }
                }
            }





            else if(choice =="6")
            {
                return;
                Console.WriteLine("Вы успешно вышли из предложение учет сотрудников");
            }

        }
    }
}
