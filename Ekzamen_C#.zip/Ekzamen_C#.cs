﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Threading.Channels;

namespace ConsoleApp29
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("__________________________________________________________");
            Console.WriteLine("Меню");
            Console.WriteLine("1.Вход");
            Console.WriteLine("2.Выход");
            Console.WriteLine("__________________________________________________________");
            Console.Write("Введите цифру:");
            string choice = Console.ReadLine();
            if (choice == "1")
            {
                Dictionary<string, Dictionary<string, string>> translations = new Dictionary<string, Dictionary<string, string>>();

                //Добавление языков 
                translations.Add("русский", new Dictionary<string, string>()
            {
            { "Привет", "hello" },
            { "Как дела?", "how are you?" },
            { "Я тебя люблю", "I love you" }       
            });

                translations.Add("английский", new Dictionary<string, string>()
            {
            { "hello", "привет" },
            { "how are you?", "как дела?" },
            { "I love you", "я тебя люблю" }
            });


                while (true)
                {
                    Console.WriteLine("__________________________________________________________");
                    Console.WriteLine("Меню");
                    Console.WriteLine("1.Перевести слово");
                    Console.WriteLine("2.Сохранить Словарь в файл");
                    Console.WriteLine("3.Сохранить перевод слова в файл");                 
                    Console.WriteLine("4.Выход");
                    Console.WriteLine("__________________________________________________________");
                    Console.Write("Введите цифру:");
                    string choice_2 = Console.ReadLine();

                    if (choice_2 == "1")
                    {

                        Console.Write("Введите слово: ");
                        string word = Console.ReadLine();

                        // получение языка пользователя
                        Console.Write("Введите язык перевода (русский/англиский): ");
                        string languageCode = Console.ReadLine().ToLower();

                      
                        if (!translations.ContainsKey(languageCode))
                        {
                            Console.WriteLine("Неверный язык перевода.");
                            continue;
                        }

                        // Перевод
                        string translation;
                        if (translations[languageCode].ContainsKey(word))
                        {
                            translation = translations[languageCode][word];
                        }
                        else
                        {
                            translation = "Перевод не найден.";
                        }
                      
                        Console.WriteLine("Перевод: " + translation);

                        Console.Write("Продолжить  (да/нет): ");
                        string answer = Console.ReadLine().ToLower();
                        if (answer != "да")
                        {
                            break;
                        }
                    }
                    else if(choice_2 == "2")
                    {
                        string File_CS = "Program.cs";
                        string text = " ";
                        try
                        {
                            File.WriteAllText(File_CS,text);
                            Console.WriteLine("Словарь успешно сохранен");
                        }
                        catch(Exception ex) 
                        {
                            Console.WriteLine("Словарь не удалось сохранить");
                        }
                    }
                    else if(choice_2 == "3")
                    {
                        Console.WriteLine("Введите слово:");
                        string choice_3= Console.ReadLine();
                        
                        Console.Write("Введите язык перевода (русский/англиский): ");
                        string languageCode = Console.ReadLine().ToLower();

                    
                        if (!translations.ContainsKey(languageCode))
                        {
                            Console.WriteLine("Неверный язык перевода.");
                            continue;
                        }

                  
                        string translation;
                        if (translations[languageCode].ContainsKey(choice_3))
                        {
                            translation = translations[languageCode][choice_3];
                        }
                        else
                        {
                            translation = "Перевод не найден.";
                        }

                        Console.WriteLine("Перевод: " + translation);

                        using (StreamWriter writer=new StreamWriter("Перевод.txt"))
                        {
                            writer.WriteLine("__________________________________________________________");
                            writer.Write("Слово которое вы ввёли:");
                            writer.WriteLine(choice_3);
                            writer.Write("Перевод слова:");
                            writer.WriteLine(translation);
                            writer.WriteLine("__________________________________________________________");

                        }
                        Console.WriteLine("Перевод  пользователя успешно сохранено в текстовый документ");
                    }
                   
                    else if(choice_2 == "4")
                    {
                        Console.WriteLine("Вы успешно вышли с предложение Словарь!!!");
                        return;
                    }
                }
            }
            else if (choice == "2")
            {
                Console.WriteLine("Вы успешно вышли с предложение Словарь!!!");
               return;
            }
        }
    }
}
