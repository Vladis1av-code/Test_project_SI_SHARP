CREATE TABLE FootballTeams (
 Id INT IDENTITY(1,1) PRIMARY KEY,
    TeamName NVARCHAR(50) NOT NULL,  
    City NVARCHAR(50),               
    Wins INT,                        
    Losses INT,                       
    Draws INT                        
);