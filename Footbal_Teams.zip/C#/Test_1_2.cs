﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Footbal;
using Footbal_2;
using System.Data.SqlClient;
namespace Footbal
{
     class Test_1_2
    {
        string Sql_Connection = "Data Source=DESKTOP-M09DVFG;Initial Catalog=FootballTeams;Integrated Security=True;";//Подключние к базе данных

        
      
       
       
      
        
      


        static void Main(string[] args)
        {
            

            Console.WriteLine("1.Вывести название команды");
            Console.WriteLine("2.Вывести название города");
            Console.WriteLine("3.Вывести количество побед");
            Console.WriteLine("4.Вывести поражение команды");
            Console.WriteLine("5.Вывести количество игор в ничью");
            Console.WriteLine("6.Вывести всю информацию о команде");
            string choice_users=Console.ReadLine();
            if (choice_users == "1")
            {
                string Sql_Connection = "Data Source=DESKTOP-M09DVFG;Initial Catalog=FootballTeams;Integrated Security=True;";//Подключние к базе данных
                string sql_name_teams = "SELECT TeamName FROM FootballTeams WHERE TeamName = @TeamName";
                using(SqlConnection connection=new SqlConnection(Sql_Connection))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(sql_name_teams, connection))
                    {
                        using(SqlDataReader reader=command.ExecuteReader())
                        {
                            if(reader.Read())
                            {
                                Console.WriteLine("___________________________________________________________");
                                Console.WriteLine($"Название команды+{reader["TeamName"]}");
                                Console.WriteLine("___________________________________________________________");
                            }
                        }
                    }
                }

            }
            else if (choice_users == "2")
            {
                string Sql_Connection = "Data Source=DESKTOP-M09DVFG;Initial Catalog=FootballTeams;Integrated Security=True;";//Подключние к базе данных
                string sql_name_city = "SELECT City FROM FootballTeams WHERE City=@City";

                using (SqlConnection connection = new SqlConnection(Sql_Connection))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(sql_name_city, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                Console.WriteLine("___________________________________________________________");
                                Console.WriteLine($"Название города+{reader["City"]}");
                                Console.WriteLine("___________________________________________________________");
                            }
                        }
                    }
                }
            }
            else if (choice_users == "3")
            {
                string Sql_Connection = "Data Source=DESKTOP-M09DVFG;Initial Catalog=FootballTeams;Integrated Security=True;";//Подключние к базе данных
                string sql_quantity_win = "SELECT Wins FROM FootballTeams WHERE Wins=@Wins";

                using (SqlConnection connection = new SqlConnection(Sql_Connection))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(sql_quantity_win, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                Console.WriteLine("___________________________________________________________");
                                Console.WriteLine($"Количество побед+{reader["Wins"]}");
                                Console.WriteLine("___________________________________________________________");
                            }
                        }
                    }
                }
            }
            else if (choice_users == "4")
            {
                string Sql_Connection = "Data Source=DESKTOP-M09DVFG;Initial Catalog=FootballTeams;Integrated Security=True;";//Подключние к базе данных
                string sql_defeat_losses = "SELECT Losses FROM FootballTeams WHERE Losses=@Losses";
                using (SqlConnection connection = new SqlConnection(Sql_Connection))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(sql_defeat_losses, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                Console.WriteLine("___________________________________________________________");
                                Console.WriteLine($"Количество поражение+{reader["Losses"]}");
                                Console.WriteLine("___________________________________________________________");
                            }
                        }
                    }
                }
            }
            else if (choice_users == "5")
            {
                string Sql_Connection = "Data Source=DESKTOP-M09DVFG;Initial Catalog=FootballTeams;Integrated Security=True;";//Подключние к базе данных
                string sql_num_draw = "SELECT Draw FROM FootballTeams WHERE Draw=@Draw";

                using (SqlConnection connection = new SqlConnection(Sql_Connection))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(sql_num_draw, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                Console.WriteLine("___________________________________________________________");
                                Console.WriteLine($"Количество игор в ничью: +{reader["Draw"]}");
                                Console.WriteLine("___________________________________________________________");
                            }
                        }
                    }
                }
            }
            else if (choice_users == "6")
            {
                Console.WriteLine("Введите команду про которую хотите узнать информацию:");
                string choice_45 = Console.ReadLine();

                string Sql_Connection = "Data Source=DESKTOP-M09DVFG;Initial Catalog=FootballTeams;Integrated Security=True;";//Подключние к базе данных

                string sql_full_info_teams = "SELECT * FROM FootballTeams WHERE TeamName=@TeamName";//Sql запрос
                using (SqlConnection connection=new SqlConnection(Sql_Connection))
                {
                    connection.Open();
                    using(SqlCommand command=new SqlCommand(sql_full_info_teams, connection))
                    {
                        command.Parameters.AddWithValue("@TeamName",choice_45);
                        using(SqlDataReader reader=command.ExecuteReader())
                        {
                            if(reader.Read())
                            {
                                Console.WriteLine("___________________________________________________________");
                                Console.WriteLine($"Название: + { reader["TeamName"]}");
                                Console.WriteLine($"Город: +{reader["City"]}");
                                Console.WriteLine($"Победы: +{reader["Wins"]}");
                                Console.WriteLine($"Поражение:+{reader["Losses"]}");
                                Console.WriteLine($"Ничьи:+{reader["Draw"]}");
                                Console.WriteLine("___________________________________________________________");
                            }
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Error");
            }

        }
    }
}
 