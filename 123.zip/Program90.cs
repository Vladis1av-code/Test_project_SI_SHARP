﻿using System;
using System.IO;

namespace ConsoleApp32
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Меню");
            Console.WriteLine("__________________________________________________________________________________");
            Console.WriteLine("1.Оплата за день");
            Console.WriteLine("2.Штраф за день задержка оплаты");
            Console.WriteLine("3.Сумма до оплаты без штрафа");
            Console.WriteLine("4.Штраф");
            Console.WriteLine("5.Общая сумма до оплаты");
            Console.WriteLine("6.Выход");
            Console.WriteLine("__________________________________________________________________________________");
            Console.Write("Введите цифру:");
            string choice = Console.ReadLine();

            if (choice == "1")
            {

                Console.WriteLine("Введите оплату за день:");
                string choice_money = Console.ReadLine();

                Console.WriteLine("Введите количество дней:");
                string choice_day = Console.ReadLine();

                int num1 = int.Parse(choice_money);
                int num2 = int.Parse(choice_day);
                int product = num1 * num2;
                string result = product.ToString();

                Console.WriteLine("Оплата за все дни:" + result);
                Console.WriteLine("_________________________________________________________");
                Console.WriteLine("Желаете сохранить в текстовый документ?");
                Console.WriteLine("да/нет");
                Console.Write("Введите ответ:");
                string choice_txt_file = Console.ReadLine();
                if (choice_txt_file == "да")
                {

                    string files = "Account_payable.txt";

                    try
                    {
                        using (StreamWriter writer = new StreamWriter(files))
                        {
                            writer.WriteLine("__________________________________________________________");
                            writer.WriteLine("Оплата за все дни:");
                            writer.WriteLine(result);
                            writer.WriteLine("__________________________________________________________");
                            Console.WriteLine("Вы успешно записали данные в файл");
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error txt");
                    }
                }
                else if (choice_txt_file == "нет")
                {
                    Console.WriteLine("Вы успешно вышли из предложения");
                    return;
                }
                else
                {
                    Console.WriteLine("Error");
                }


            }
            else if (choice == "2")
            {
                Console.WriteLine("Введите сумму:");
                string choice_suma = Console.ReadLine();

                Console.WriteLine("Введите дни:");
                string choice_day_2 = Console.ReadLine();

                Console.WriteLine("Введите процент за день:");
                string choice_percent = Console.ReadLine();

                
                try
                {
                    int num3 = int.Parse(choice_suma);
                    int num4 = int.Parse(choice_day_2);
                    int num6 = int.Parse(choice_percent);

                    
                    int totalAmount = num3 * num4 * (100 + num6) / 100; 

                    Console.WriteLine("Общая сумма с процентами: {0}", totalAmount);

                    Console.WriteLine("Хотите сохранить информацию в текстовый документ?");
                    Console.WriteLine("да/нет");
                    Console.Write("Введите ответ:");
                    string pr=Console.ReadLine();
                    if (pr == "да")
                    {
                        string files = "Account_payable.txt";

                        try
                        {
                            using (StreamWriter writer = new StreamWriter(files))
                            {
                                writer.WriteLine("__________________________________________________________");
                                writer.WriteLine("Общая сумма с процентами:");
                                writer.WriteLine(totalAmount);
                                writer.WriteLine("__________________________________________________________");
                                Console.WriteLine("Вы успешно записали данные в файл");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error txt");
                        }
                    }
                    else if(pr =="нет")
                    {
                        Console.WriteLine("Вы успешно вышли из программы");
                        return;
                    }
                    else
                    {
                         Console.WriteLine("Error");
                    }
                }
                catch (FormatException ex)
                {
                    Console.WriteLine("Error");
                }

            }
            else if (choice == "3")
            {
                Console.WriteLine("Введите оплату за день:");
                string choice_money = Console.ReadLine();

                Console.WriteLine("Введите количество дней:");
                string choice_day = Console.ReadLine();

                int num1 = int.Parse(choice_money);
                int num2 = int.Parse(choice_day);
                int product = num1 * num2;
                string result = product.ToString();

                Console.Write("Сумма до оплаты без штрафа:");
                Console.WriteLine(result);
                Console.Write("Введите ответ:");
                Console.WriteLine("да/нет");
                string choice_txt_file_1 = Console.ReadLine();

                if (choice_txt_file_1 == "да")
                {
                    string files = "Account_payable.txt";

                    try
                    {
                        using (StreamWriter writer = new StreamWriter(files))
                        {
                            writer.WriteLine("__________________________________________________________");
                            writer.WriteLine("Оплата без штрафа:");
                            writer.WriteLine(result);
                            writer.WriteLine("__________________________________________________________");
                            Console.WriteLine("Вы успешно записали данные в файл");
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error txt");
                    }

                }
                else if (choice_txt_file_1 == "нет")
                {
                    Console.WriteLine("Вы успешно вышли из предложения");
                    return;
                }
                else
                {
                    Console.WriteLine("Error");
                }
            }

            else if (choice == "4")
            {
                Console.WriteLine("Меню");

                Console.WriteLine("1.Штраф за неправильную парковку");
                Console.WriteLine("2.Штраф за превышение скорости");
                Console.WriteLine("3.Штраф за нетрезвом состоянии.");
                Console.WriteLine("4.Штраф за нарушение правил остановок и стоянок");
                Console.WriteLine("5.Штраф за использовании телефоном во время управления");
                Console.WriteLine("6.Выход");
                Console.Write("Введите цифру:");
                string fine = Console.ReadLine();
                if (fine == "1")
                {
                    Console.Write("Введите количество штрафов:");
                    int choice_fine_1 = int.Parse(Console.ReadLine());
                    int choice_2 = 1920;
                    int res = choice_fine_1 * choice_2;
                    Console.WriteLine("Вам надо выплатить:" + res + "грн");
                    Console.Write("Введите ответ:");
                    Console.WriteLine("да/нет");
                    string choice_txt_file_2 = Console.ReadLine();

                    if (choice_txt_file_2 == "да")
                    {
                        string filePath = "Account_payable.txt";

                        try
                        {

                            using (StreamWriter writer = new StreamWriter(filePath))
                            {
                                writer.WriteLine("__________________________________________________________");
                                writer.WriteLine("Вам надо выплатить штраф за неправильную парковку:");
                                writer.WriteLine(res);
                                writer.WriteLine("__________________________________________________________");
                                Console.WriteLine("Вы успешно записали данные в файл");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error txt");
                        }
                    }
                    else if (choice_txt_file_2 == "нет")
                    {
                        Console.WriteLine("Вы успешно вышли из предложения");
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Error");
                    }

                }
                else if (fine == "2")
                {
                    Console.Write("Введите количество штрафов:");
                    int choice_fine_2 = int.Parse(Console.ReadLine());
                    int choice_2 = 2050;
                    int res_2 = choice_fine_2 * choice_2;
                    Console.WriteLine("Вам надо выплатить:" + res_2 + "грн");
                    Console.Write("Введите ответ:");
                    Console.WriteLine("да/нет");
                    string choice_txt_file_3 = Console.ReadLine();

                    if (choice_txt_file_3 == "да")
                    {
                        string filePath = "Account_payable.txt";

                        try
                        {

                            using (StreamWriter writer = new StreamWriter(filePath))
                            {
                                writer.WriteLine("__________________________________________________________");
                                writer.WriteLine("Вам надо выплатить штраф за превышение скорости:");
                                writer.WriteLine(res_2);
                                writer.WriteLine("__________________________________________________________");
                                Console.WriteLine("Вы успешно записали данные в файл");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error txt");
                        }
                    }
                    else if (choice_txt_file_3 == "нет")
                    {
                        Console.WriteLine("Вы успешно вышли из предложения");
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Error");
                    }
                }
                else if (fine == "3")
                {
                    Console.Write("Введите количество штрафов:");
                    int choice_fine_3 = int.Parse(Console.ReadLine());
                    int choice_3 = 1550;
                    int res_3 = choice_fine_3 * choice_3;
                    Console.WriteLine("Вам надо выплатить:" + res_3 + "грн");
                    Console.Write("Введите ответ:");
                    Console.WriteLine("да/нет");
                    string choice_txt_file_4 = Console.ReadLine();

                    if (choice_txt_file_4 == "да")
                    {
                        string filePath = "Account_payable.txt";

                        try
                        {

                            using (StreamWriter writer = new StreamWriter(filePath))
                            {
                                writer.WriteLine("__________________________________________________________");
                                writer.WriteLine("Вам надо выплатить штраф за нетрезвом состоянии:");
                                writer.WriteLine(res_3);
                                writer.WriteLine("__________________________________________________________");
                                Console.WriteLine("Вы успешно записали данные в файл");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error txt");
                        }
                    }
                    else if (choice_txt_file_4 == "нет")
                    {
                        Console.WriteLine("Вы успешно вышли из предложения");
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Error");
                    }
                }
                else if (fine == "4")
                {
                    Console.Write("Введите количество штрафов:");
                    int choice_fine_4 = int.Parse(Console.ReadLine());
                    int choice_4 = 3200;
                    int res_4 = choice_fine_4 * choice_4;
                    Console.WriteLine("Вам надо выплатить:" + res_4 + "грн");
                    Console.Write("Введите ответ:");
                    Console.WriteLine("да/нет");
                    string choice_txt_file_5 = Console.ReadLine();

                    if (choice_txt_file_5 == "да")
                    {
                        string filePath = "Account_payable.txt";

                        try
                        {

                            using (StreamWriter writer = new StreamWriter(filePath))
                            {
                                writer.WriteLine("__________________________________________________________");
                                writer.WriteLine("Вам надо выплатить штраф за правил остановок и стоянок :");
                                writer.WriteLine(res_4);
                                writer.WriteLine("__________________________________________________________");
                                Console.WriteLine("Вы успешно записали данные в файл");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error txt");
                        }
                    }
                    else if (choice_txt_file_5 == "нет")
                    {
                        Console.WriteLine("Вы успешно вышли из предложения");
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Error");
                    }
                }
                else if (fine == "5")
                {
                    Console.Write("Введите количество штрафов:");
                    int choice_fine_5 = int.Parse(Console.ReadLine());
                    int choice_5 = 1700;
                    int res_5 = choice_fine_5 * choice_5;
                    Console.WriteLine("Вам надо выплатить:" + res_5 + "грн");
                    Console.Write("Введите ответ:");
                    Console.WriteLine("да/нет");
                    string choice_txt_file_6 = Console.ReadLine();

                    if (choice_txt_file_6 == "да")
                    {
                        string filePath = "Account_payable.txt";

                        try
                        {

                            using (StreamWriter writer = new StreamWriter(filePath))
                            {
                                writer.WriteLine("__________________________________________________________");
                                writer.WriteLine("Вам надо выплатить штраф за правил остановок и стоянок :");
                                writer.WriteLine(res_5);
                                writer.WriteLine("__________________________________________________________");
                                Console.WriteLine("Вы успешно записали данные в файл");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error txt");
                        }
                    }
                    else if (choice_txt_file_6 == "нет")
                    {
                        Console.WriteLine("Вы успешно вышли из предложения");
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Error");
                    }
                }

                else if (choice == "5")
                {
                    Console.WriteLine("Меню");
                    Console.WriteLine("1.Штраф за неправильную парковку");
                    Console.WriteLine("2.Штраф за превышение скорости");
                    Console.WriteLine("3.Штраф за нетрезвом состоянии.");
                    Console.WriteLine("4.Штраф за нарушение правил остановок и стоянок");
                    Console.WriteLine("5.Штраф за использовании телефоном во время управления");
                    Console.WriteLine("6.Выход");
                    Console.WriteLine("Введите штраф:");
                    string fine_choice=Console.ReadLine();

                   

                    if(fine_choice=="1")
                    {
                        Console.Write("Введите количество штрафов:");
                        int choice_fine_1 = int.Parse(Console.ReadLine());

                        Console.WriteLine("Введите оплату за день:");
                        string choice_money = Console.ReadLine();
                        Console.WriteLine("Введите количество дней:");
                        string choice_day = Console.ReadLine();

                        int num1 = int.Parse(choice_money);
                        int num2 = int.Parse(choice_day);
                        int product = num1 * num2;
                        int choice_2 = 1920;
                        int res = choice_fine_1 * choice_2 + product;
                        string result = product.ToString();


                        Console.WriteLine("Вам надо выплатить:" + result + "грн");
                        Console.Write("Введите ответ:");
                        Console.WriteLine("да/нет");
                        string choice_txt_file_0 = Console.ReadLine();

                       

                        if (choice_txt_file_0 == "да")
                        {
                            string filePath = "Account_payable.txt";

                            try
                            {

                                using (StreamWriter writer = new StreamWriter(filePath))
                                {
                                    writer.WriteLine("__________________________________________________________");
                                    writer.WriteLine("Общая сумма до выплат:");
                                    writer.WriteLine(result);
                                    writer.WriteLine("__________________________________________________________");
                                    Console.WriteLine("Вы успешно записали данные в файл");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Error txt");
                            }
                        }
                        else if (choice_txt_file_0 == "нет")
                        {
                            Console.WriteLine("Вы успешно вышли из предложения");
                            return;
                        }
                        else
                        {
                            Console.WriteLine("Error");
                        }
                    }
                    else if(fine_choice=="2")
                    {
                        Console.Write("Введите количество штрафов:");
                        int choice_fine_2 = int.Parse(Console.ReadLine());

                        Console.WriteLine("Введите оплату за день:");
                        string choice_money = Console.ReadLine();
                        Console.WriteLine("Введите количество дней:");
                        string choice_day = Console.ReadLine();

                        int num19 = int.Parse(choice_money);
                        int num29 = int.Parse(choice_day);
                        int product90 = num19 * num29;

                        int choice_2 = 2050;
                        int res_2 = choice_fine_2 * choice_2 + product90;
                        Console.WriteLine("Вам надо выплатить:" + res_2 + "грн");
                        Console.Write("Введите ответ:");
                        Console.WriteLine("да/нет");
                        string choice_txt_file_3 = Console.ReadLine();

                        if (choice_txt_file_3 == "да")
                        {
                            string filePath = "Account_payable.txt";

                            try
                            {

                                using (StreamWriter writer = new StreamWriter(filePath))
                                {
                                    writer.WriteLine("__________________________________________________________");
                                    writer.WriteLine("Общая сумма до выплат:");
                                    writer.WriteLine(res_2);
                                    writer.WriteLine("__________________________________________________________");
                                    Console.WriteLine("Вы успешно записали данные в файл");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Error txt");
                            }
                        }
                        else if (choice_txt_file_3 == "нет")
                        {
                            Console.WriteLine("Вы успешно вышли из предложения");
                            return;
                        }
                        else
                        {
                            Console.WriteLine("Error");
                        }
                    }
                    else if(fine_choice=="3")
                    {
                        Console.Write("Введите количество штрафов:");
                        int choice_fine_24 = int.Parse(Console.ReadLine());

                        Console.WriteLine("Введите оплату за день:");
                        string choice_money45 = Console.ReadLine();
                        Console.WriteLine("Введите количество дней:");
                        string choice_day45 = Console.ReadLine();

                        int num19 = int.Parse(choice_money45);
                        int num29 = int.Parse(choice_day45);
                        int product901 = num19 * num29;

                        int choice_3 = 1550;
                        int res_3 = choice_fine_24 * choice_3 + product901;
                        Console.WriteLine("Вам надо выплатить:" + res_3 + "грн");
                        Console.Write("Введите ответ:");
                        Console.WriteLine("да/нет");
                        string choice_txt_file_43 = Console.ReadLine();

                        if (choice_txt_file_43 == "да")
                        {
                            string filePath = "Account_payable.txt";

                            try
                            {

                                using (StreamWriter writer = new StreamWriter(filePath))
                                {
                                    writer.WriteLine("__________________________________________________________");
                                    writer.WriteLine("Общая сумма до выплат:");
                                    writer.WriteLine(res_3);
                                    writer.WriteLine("__________________________________________________________");
                                    Console.WriteLine("Вы успешно записали данные в файл");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Error txt");
                            }
                        }
                        else if (choice_txt_file_43 == "нет")
                        {
                            Console.WriteLine("Вы успешно вышли из предложения");
                            return;
                        }
                        else
                        {
                            Console.WriteLine("Error");
                        }
                    }
                    else if(fine_choice=="4")
                    {
                        Console.Write("Введите количество штрафов:");
                        int choice_fine_2424 = int.Parse(Console.ReadLine());

                        Console.WriteLine("Введите оплату за день:");
                        string choice_money4545 = Console.ReadLine();

                        Console.WriteLine("Введите количество дней:");
                        string choice_day4545 = Console.ReadLine();

                        int num1926 = int.Parse(choice_money4545);
                        int num2926 = int.Parse(choice_day4545);
                        int product901 = num1926 * num2926;

                        int choice_4 = 3200;
                        int res_4 = choice_fine_2424 * choice_4 +product901;
                        Console.WriteLine("Вам надо выплатить:" + res_4 + "грн");
                        Console.Write("Введите ответ:");
                        Console.WriteLine("да/нет");
                        string choice_txt_file_57 = Console.ReadLine();

                        if (choice_txt_file_57 == "да")
                        {
                            string filePath = "Account_payable.txt";

                            try
                            {

                                using (StreamWriter writer = new StreamWriter(filePath))
                                {
                                    writer.WriteLine("__________________________________________________________");
                                    writer.WriteLine("Общая сумма до выплат:");
                                    writer.WriteLine(res_4);
                                    writer.WriteLine("__________________________________________________________");
                                    Console.WriteLine("Вы успешно записали данные в файл");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Error txt");
                            }
                        }
                        else if (choice_txt_file_57 == "нет")
                        {
                            Console.WriteLine("Вы успешно вышли из предложения");
                            return;
                        }
                        else
                        {
                            Console.WriteLine("Error");
                        }
                    }
                    else if(fine_choice == "5")
                    {
                        Console.Write("Введите количество штрафов:");
                        int choice_fine_2423 = int.Parse(Console.ReadLine());

                        Console.WriteLine("Введите оплату за день:");
                        string choice_money4544 = Console.ReadLine();

                        Console.WriteLine("Введите количество дней:");
                        string choice_day4544 = Console.ReadLine();

                        int num19 = int.Parse(choice_money4544);
                        int num29 = int.Parse(choice_day4544);
                        int product901 = num19 * num29;

                        int choice_5 = 1700;
                        int res_567 = choice_fine_2423 * choice_5 + product901;
                        Console.WriteLine("Вам надо выплатить:" + res_567 + "грн");
                        Console.Write("Введите ответ:");
                        Console.WriteLine("да/нет");
                        string choice_txt_file_689 = Console.ReadLine();

                        if (choice_txt_file_689 == "да")
                        {
                            string filePath = "Account_payable.txt";

                            try
                            {

                                using (StreamWriter writer = new StreamWriter(filePath))
                                {
                                    writer.WriteLine("__________________________________________________________");
                                    writer.WriteLine("Общая сумма до выплат:");
                                    writer.WriteLine(res_567);
                                    writer.WriteLine("__________________________________________________________");
                                    Console.WriteLine("Вы успешно записали данные в файл");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Error txt");
                            }
                        }
                        else if (choice_txt_file_689 == "нет")
                        {
                            Console.WriteLine("Вы успешно вышли из предложения");
                            return;
                        }
                        else
                        {
                            Console.WriteLine("Error");
                        }
                    }
                    else if(fine_choice=="6")
                    {
                        Console.WriteLine("Вы успешно вышли из предложения");
                        return;
                    }
                }
                else if (choice == "6")
                {
                    Console.WriteLine("Вы успешно вышли из предложения");
                    return;
                }
                else
                {
                    Console.WriteLine("Error");
                }
            }
        }
    }
}
