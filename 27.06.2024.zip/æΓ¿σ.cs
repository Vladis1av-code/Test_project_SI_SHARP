﻿using System;
using System.IO;
using System.Security.Cryptography.X509Certificates;
namespace ConsoleApp30
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Меню");
            Console.WriteLine("1.Добавить Стих");
            Console.WriteLine("2.Удалить Стих");
            Console.WriteLine("3.Изменить информацию про Стих");
            Console.WriteLine("4.Искать Стих за разными характеристиками");
            Console.WriteLine("5.Сохранить коллекцию стихов у файлов");
            Console.WriteLine("6.Загрузить коллекцию стихов з файла");
            Console.WriteLine("7.Выход");

            Console.Write("Введите цифру:");
            string choice=Console.ReadLine();

            if (choice == "1")//+
            {
                Console.Write("Введите название стиха:");
                string name = Console.ReadLine();

                Console.WriteLine("Введите Ф.И.О. автора:");
                string name_author = Console.ReadLine();

                Console.WriteLine("Введите год написание стиха:");
                string year_verse = Console.ReadLine();

                Console.WriteLine("Введите текст стиха:");
                string text = Console.ReadLine();

                Console.WriteLine("Введите тему стиха:");
                string theme_verse = Console.ReadLine();

                using (StreamWriter write = new StreamWriter("Стих.txt"))//Запись в текстовый документ
                {
                    write.WriteLine("Название стиха:" + name);
                    write.WriteLine("Ф.И.О. автора:" + name_author);
                    write.WriteLine("Год написание стиха:" + year_verse);
                    write.WriteLine("Тема стиха:" + theme_verse);
                    write.WriteLine(text);
                }
                Console.WriteLine("Вы успешно сохранили Стих");
            }
            else if (choice == "2")//+
            {
                Console.WriteLine("Введите путь где храниться ваш файл:");
                string path_users= Console.ReadLine();

                string path_delete = path_users;
                try
                {
                    Console.WriteLine("Файл успешно был удален");
                    File.Delete(path_users);
                }
                catch(Exception ex)
                {
                    Console.WriteLine("Файл не был удален");
                }

            }
            //____________________________________________________________________________
            else if (choice == "3")//+
            {
                Console.WriteLine("_______________________________________________________________");
                Console.WriteLine("Меню");
                Console.WriteLine("1.Изменить строку Стиха");
                Console.WriteLine("2.Удалить строку Стиха");
                Console.WriteLine("3.Изменить расширение файла где сохранен Стих");
                Console.WriteLine("4.Выход");
                Console.Write("Введите число:");
                string print_users = Console.ReadLine();
                if (print_users == "1")
                {
                  
                }
                else if (print_users == "2")//+
                {
                    Console.WriteLine("Введите путь до файла и расширение файла:");
                    string file_p = Console.ReadLine(); //Путь до файла

                    Console.WriteLine("Введите строку которую желаете удалить:");
                    string Number = Console.ReadLine();

                    List<string> lines= File.ReadAllLines(file_p).ToList();
                    //Получает от пользователя которые строки надо удалить
                    List<string>linesToRemove=new List<string>() { Number };

                    //удаляет строки из списка
                    lines.RemoveAll(line=>linesToRemove.Contains(line));

                    //Возращает все что осталось в файл
                    File.WriteAllLines(file_p, lines);

                }
            
        
                if(print_users == "3")//+
                {
                    Console.WriteLine("Введите путь до файла:");
                    string path_user1= Console.ReadLine();

                    Console.WriteLine("Введите расширение файла:");
                    string path_user11= Console.ReadLine();

                    string p=Path.ChangeExtension(path_user1,path_user11);

                    try
                    {
                        Console.WriteLine("Вы успешно изменили расширение файла"); 
                        File.Move(path_user1, p);
                    }
                    catch (Exception ex) 
                    {
                        Console.WriteLine("Ошибка расширение не было изменено ");
                    }
                }
                if(print_users == "4")//+
                {
                    return;
                    Console.WriteLine("Вы успешно вышли из предложение");
                }
            }
            //________________________________________________________________________
            else if (choice == "4")
            {
                Console.WriteLine("Меню");
                Console.WriteLine("1.Искать по названию");
                Console.WriteLine("2.Искать по размеру байт");
                Console.WriteLine("3.Искать по содержимому в файле:");
                Console.WriteLine("4.Выход");

                Console.Write("Введите цифру:");
                string menu= Console.ReadLine();

                if(menu == "1")//+
                {
                    Console.WriteLine("Введите путь до файла:");
                    string path_us2= Console.ReadLine();

                    Console.WriteLine("Введите имя файла:");
                    string name_txt= Console.ReadLine();

                    string path = path_us2;
                    string searchPattern = name_txt;

                    IEnumerable<string> files = Directory.EnumerateFiles(path, searchPattern);

                    foreach (string file in files)
                    {
                        Console.WriteLine("Найден файл: " + file);
                    }
                }
                else if(menu == "2")//-
                {
                    Console.WriteLine("Введите путь до файла:");
                    string choice_users_3= Console.ReadLine();
                    long Size = 1024 * 1024;//1mb
                    string path_start = choice_users_3;

                   // IEnumerable<FileInfo> files=FindFilesBySize(path_start);
                }
                else if(menu=="3")//-
                {
                    Console.WriteLine("Введите текст который в файле:");
                    string text_file= Console.ReadLine();

                    Console.WriteLine("Введите путь до файла:");
                    string path_8= Console.ReadLine();

                    string text_2 = text_file;   // 
                    string pa = path_8;

                    IEnumerable<string> FindFilesByContent(string pa, string text_2)
                    {
                        List<string> results = new List<string>();

                        foreach (var directory in Directory.EnumerateDirectories(pa))
                        {
                            results.AddRange(FindFilesByContent(directory, text_2));
                        }

                        foreach (var file in Directory.EnumerateFiles(pa))
                        {
                           // if (File.ReadAllBytes(file.FullName).Contains(text_2))
                            {
                               // results.Add(file.FullName);
                            }
                        }

                        return results;
                    }

                }
                else if(menu=="4")
                {
                    Console.WriteLine("Вы успешно вышли из предложение Словарь");
                    return;
                }
                else
                {
                    Console.WriteLine("Ошибка");                   
                }    
               
            }
            else if (choice == "5")//+
            {
                Console.Write("Введите название первого стиха:");
                string name_2 = Console.ReadLine();

                Console.WriteLine("Введите название второго стиха:");
                string name_3 = Console.ReadLine();

                Console.WriteLine("Введите первого Ф.И.О. автора:");
                string name_author_2 = Console.ReadLine();

                Console.WriteLine("Введите второго Ф.И.О. автора:");
                string name_author_3= Console.ReadLine();

                Console.WriteLine("Введите год первого написаного стиха:");
                string year_verse_2 = Console.ReadLine();

                Console.WriteLine("Введите год второго написаного стиха:");
                string year_verse_3 = Console.ReadLine();

                Console.WriteLine("Введите первый текст стиха:");
                string text_2 = Console.ReadLine();

                Console.WriteLine("Введите второй текст стиха:") ;
                string text_3 = Console.ReadLine();

                Console.WriteLine("Введите первый тему стиха:");
                string theme_verse_2 = Console.ReadLine();

                Console.WriteLine("Введите вторую тему стиха:");
                string theme_verse_3 = Console.ReadLine();

                Console.WriteLine("Введите путь где будет хранится коллекция:");
                string path_collections= Console.ReadLine();

                string path = path_collections;

                try
                {
                    Directory.CreateDirectory(path);
                    Console.WriteLine(" "+ path);

                    using (StreamWriter write = new StreamWriter("Стих.txt"))//Запись в текстовый документ
                    {
                        write.WriteLine("Название стиха:" + name_2);
                        write.WriteLine("Ф.И.О. автора:" + name_author_2);
                        write.WriteLine("Год написание стиха:" + year_verse_2);
                        write.WriteLine("Тема стиха:" + theme_verse_2);
                        write.WriteLine(text_2);
                    }
                  
                    using(StreamWriter writer=new StreamWriter("Стих_2.txt"))
                    {
                        writer.WriteLine("Название стиха:" + name_3);
                        writer.WriteLine("Ф.И.О. автора:" + name_author_3);
                        writer.WriteLine("Год написание стиха:" + year_verse_3);
                        writer.WriteLine("Тема стиха:" + theme_verse_2);
                        writer.WriteLine(text_3);
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ошибка при создание коллекции");
                }

                
            }
            else if(choice=="6")
            {
                Console.WriteLine("Введите путь до файла:");
                string choice_user_14= Console.ReadLine();

                string path_57 = choice_user_14;
                try
                {
                    using(StreamReader reader=new StreamReader(path_57))
                    {
                        string line;
                        while((line=reader.ReadLine())!=null)
                        {
                            Console.WriteLine(line);
                        }
                    }
                }
                catch(Exception ex)
                {
                    Console.WriteLine("Ошибка");
                }
            }
            else if(choice=="7")//+
            {
                return;
                Console.WriteLine("Вы успешно вышли из предложение");
            }

        }
    }
}
