﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCP_Server_Win_forms
{
    public partial class Form1 : Form
    {
        private TcpListener tcpListener;
        private Thread listenThread;
        private bool isRunning;

        public Form1()
        {
            InitializeComponent();
            textBox2.Text = "8080";
            textBox3.Text = "127.0.0.1";
        }

        private void button1_Click(object sender, EventArgs e)//Включить
        {
            int port = int.Parse(textBox2.Text);
            IPAddress localAddr = IPAddress.Parse(textBox3.Text);
            tcpListener = new TcpListener(localAddr, port);
            listenThread = new Thread(new ThreadStart(ListenForClients));
            listenThread.Start();
            isRunning = true;
            textBox1.AppendText($"Сервер запущен на {localAddr}:{port}\r\n");
        }
        private void button2_Click(object sender, EventArgs e)//Выключить 
        {
            isRunning = false;
            tcpListener.Stop();
            textBox1.AppendText("Сервер остановлен.\r\n");
        }
        private void textBox1_TextChanged(object sender, EventArgs e)//Вывод информации 
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)//IP
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)//Port
        {

        }
        private void ListenForClients()
        {
            tcpListener.Start();

            while (isRunning)
            {
                try
                {
                    TcpClient client = tcpListener.AcceptTcpClient();
                    Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
                    clientThread.Start(client);
                }
                catch (SocketException)
                {
                    // Исключение может быть выброшено при остановке сервера
                    break;
                }
            }
        }
        private void HandleClientComm(object client_obj)
        {
            TcpClient tcpClient = (TcpClient)client_obj;
            NetworkStream clientStream = tcpClient.GetStream();

            // Чтение данных
            byte[] message = new byte[4096];
            int bytesRead;

            try
            {
                // Получаем имя пользователя
                bytesRead = clientStream.Read(message, 0, message.Length);
                string username = Encoding.ASCII.GetString(message, 0, bytesRead).Trim();

                // Сообщаем о новом подключении
                string connectMessage = $"[{DateTime.Now}] {username} подключился.";
                AppendTextBox(connectMessage);

                while (isRunning && tcpClient.Connected)
                {
                    bytesRead = clientStream.Read(message, 0, message.Length);

                    if (bytesRead == 0)
                    {
                        // Клиент отключился
                        break;
                    }

                    // Обработка данных от клиента (по необходимости)
                }
            }
            catch (Exception)
            {
                // Обработка исключений при чтении данных
            }
            finally
            {
                // Клиент отключился
                string disconnectMessage = $"[{DateTime.Now}] клиент отключился.";
                AppendTextBox(disconnectMessage);
                tcpClient.Close();
            }
        }

        private void AppendTextBox(string message)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<string>(AppendTextBox), new object[] { message });
                return;
            }

            textBox1.AppendText(message + "\r\n");
        }
    }
}       
 
    

   

