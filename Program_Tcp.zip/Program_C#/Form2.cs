﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp36
{
    public partial class Form2 : Form
    {
        private TcpClient client;

        public Form2()
        {
            InitializeComponent();
           
        }

   
     

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string nameuser = textBox3.Text;
            string Ip = textBox6.Text;
            int Port;
            if (int.TryParse(textBox6.Text, out Port))
            {
                try
                {
                    client = new TcpClient(Ip, Port);
                    NetworkStream stream = client.GetStream();

                    // Отправляем имя пользователя на сервер
                    byte[] data = Encoding.ASCII.GetBytes(nameuser);
                    stream.Write(data, 0, data.Length);

                    MessageBox.Show("Подключено к серверу.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Form1 form1 = new Form1();
                    form1.Show();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Не удалось подключиться к серверу: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите корректный порт.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

       
    }

