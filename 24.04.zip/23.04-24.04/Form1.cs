﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp31
{
    public partial class Form1 : Form
    {
        private List<int> numbers = new List<int>();
        private ManualResetEventSlim doneGenerating = new ManualResetEventSlim(false);
        public Form1()
        {
            InitializeComponent();
            button1.Click += button1_Click;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Task.Run(() => GenerateNumbers());

            // Створення потоків для аналізу даних
            Task.Run(() => FindMax());
            Task.Run(() => FindMin());
            Task.Run(() => CalculateAverage());
          
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void GenerateNumbers()
        {
            Random random = new Random();
            for (int i = 0; i < 1000; i++)
            {
                numbers.Add(random.Next(0, 5001));
            }
            this.Invoke(new Action(() =>
            {
                textBox1.Text = string.Join(", ", numbers);
            }));

           
            doneGenerating.Set(); // Сигналізуємо іншим потокам, що генерація завершена


        
        }

        private void FindMax()
        {
            doneGenerating.Wait(); // Чекаємо на завершення генерації чисел
            int max = numbers.Max();
            MessageBox.Show($"Максимальне число: {max}");
          
        }

        private void FindMin()
        {
            doneGenerating.Wait(); // Чекаємо на завершення генерації чисел
            int min = numbers.Min();
            MessageBox.Show($"Мінімальне число: {min}");
        }

        private void CalculateAverage()
        {
            doneGenerating.Wait(); // Чекаємо на завершення генерації чисел
            double average = numbers.Average();
            MessageBox.Show($"Середнє арифметичне: {average}");
        }
    }
}
