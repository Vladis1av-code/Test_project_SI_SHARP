﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetStatExample
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo("netstat", "-a -n")
            {
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            string data = string.Empty;
            using (Process process = new Process())
            { 
                process.StartInfo = startInfo;
                process.Start();

                using (StreamReader reader = process.StandardOutput)
                { 
                    data = reader.ReadToEnd();
                }
            }
            Console.WriteLine(data);
            Console.ReadLine();
        }
    }
}
