﻿using System.Collections.Specialized;
using static System.Reflection.Metadata.BlobBuilder;

namespace _Список_книг_до_прочитання
{
    class Program
    {
        class Book
        {
            public string? Title { get; set; }
            public string? Author { get; set; }
            public string? List { get; set; }
            private List<Book> books = new List<Book>();

            public void choice()
            {
                Console.WriteLine("__________________________________________________");
                Console.WriteLine("Меню");
                Console.WriteLine("1. Добавить книгу в список");
                Console.WriteLine("2. Удалить книгу из списка");
                Console.WriteLine("3. Проверить есть ли книга в списке");
                Console.WriteLine("__________________________________________________");
                int choice;
                try
                {
                    choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            
                            Console.WriteLine("Введите название книги:");
                            string =Title = Console.ReadLine();
                            Console.WriteLine("Введите имя автора:");
                            string author = Console.ReadLine();
                            books.Add(new Book { Title = Title, Author = author });
                            Console.WriteLine("Книга успешно добавлена в список");
                            break;
                        case 2:
                            Console.WriteLine("Введите название книги для удаления:");
                            string Title = Console.ReadLine();

                            Book bookToRemove = books.Find(b => b.Title == Title);

                            if (bookToRemove != null)
                            {
                                books.Remove(bookToRemove);
                                Console.WriteLine("Книга \"" + Title + "\" успешно удалена из списка.");
                            }
                            else
                            {
                                Console.WriteLine("Книга \"" + Title + "\" не найдена в списке.");
                            }
                            break;
                        case 3:
                            Console.WriteLine("Введите название книги для проверки:");
                            string Title = Console.ReadLine();

                            bool bookExists = books.Any(b => b.Title == Title);

                            if (bookExists)
                            {
                                Console.WriteLine("Книга \"" + Title + "\" есть в списке.");
                            }
                            else
                            {
                                Console.WriteLine("Книга \"" + Title + "\" не найдена в списке.");
                            }
                            break;
                        default:
                            Console.WriteLine("Неверный выбор. Пожалуйста, выберите пункт из меню.");
                            break;
                    }

                }
                catch (FormatException) 
                {
                    Console.WriteLine("Неверный формат ввода. Пожалуйста, введите целое число.");
                }
                catch (Exception e) 
                {
                    Console.WriteLine("Произошла ошибка: " + e.Message);
                }

            }
        }
            public void Main(string[] args)
            {
            Book book = new Book();

            while (true)
            {
                book.choice();
                Console.WriteLine("Хотите продолжить? ");
                string answer = Console.ReadLine().ToLower();

                if (answer != "да")
                {
                    break;
                }


            }
    }
    }
}
