﻿namespace joumal
{
    class New_joumal
    {

        public string? Name {  get; set; }
        public string ?time { get; set; }  
        public string? Description { get; set; }
        public string ? phone_number { get; set; }
        public string? email {  get; set; }
        public string? workers { get; set; }
        public string? publisher { get; set; }
        public string? employees { get; set; }
        

       public New_joumal()
        {

        }
//перезапуск операторов
        public static New_joumal operator+(Journal journal1,int employeesToadd)
        {
            var journal=new New_joumal();
            {
                Name=journal1.Name;
                time=journal1.Time;
                Description=journal1.Description;
                phone_number=journal1.PhoneNumber;
                email=journal1.Email;
                workers=journal1.Workers;
                employees=journal1.Employees;
                publisher=journal1.Publisher;
            }
            return journal;
        }

        public static New_joumal operator -(Journal journal1, int employeesToRemove)
        {
            var journal = new New_joumal();
            {
                Name = journal1.Name;
                time = journal1.Time;
                Description = journal1.Description;
                phone_number = journal1.PhoneNumber;
                email = journal1.Email;
                workers = journal1.Workers;
                publisher= journal1.Publisher;
                employees = Math.Max(0, journal1.Employees-employeesToRemove);
            }
            return journal;
        }

        public static bool operator ==(New_joumal journal1, New_joumal journal2)
        {
            if (ReferenceEquals(journal1, journal2)) { return true; }
            if(journal1==null || journal2==null) { return false; }
            return 
        }
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return obj is Journal journal && journal.Name == Name && journal.time == time && journal.Description == Description && journal.phone_number == phone_number && journal.email==email && journal.workers==workers && journal.employees==employees && journal.publisher==publisher;
        }

        public static bool operator !=(Journal journal1, Journal journal2)
        {
            return !(journal1 == journal2);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Name, Publisher, Price, NumberOfEmployees);
        }
        //______________________________________________________________________________________________________________________     

        public New_joumal(string _Name,string _time,string _Description,string _phone_number,string _email string _workers,string _employees,string _publisher)
        {
            Name = _Name;
            time = _time;
            Description = _Description;
            phone_number=_phone_number;
            email = _email;
            workers = _workers;
            employees = _employees;
            publisher = _publisher;
        }
        
        public void choice()
        {
            string choice_Name;
            string choice_Publisher;
            string choice_workers;

            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Введите название журнала:");
             Name=Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Введите год основание: ");
            time= Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Описание журнала:");
            Description = Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("контактный номер телефона:");
            phone_number = Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Введите свой email:");
            email = Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Введите количество рабочих которых вы хотите добавить:");
            workers=Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Введите количество рабочих:");
            employees=Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Введите название журнала:");
            choice_Name=Console.ReadLine();
            Console.WriteLine("___________________________________________________________________________");
            Console.WriteLine("Введите количество рабочих которых вы хотите уменьшить:");
           choice_workers= Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Введите Имя издателя книги:");
            choice_Publisher=Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");

        }

        public void Main(string[] args)
        {

            New_joumal jounal1 = new New_joumal { Name =choice_Name, publisher=choice_Publisher,Price=100,employees=1000};
            Console.WriteLine("___________________________________________________________________________");
            New_joumal jounal2=journal1+workers;
            Console.WriteLine($"Количество рабочих в журнале:{jounal2.employees}");
            Console.WriteLine("___________________________________________________________________________");
            New_joumal jounal3 = jounal2 - choice_workers;
            Console.WriteLine($"Количество рабочих в журнале:{jounal3.employees}");
            Console.WriteLine("___________________________________________________________________________");
            Console.WriteLine("Название журнала:",Name);
            Console.WriteLine("___________________________________________________________________________");
            Console.WriteLine("Год основание:",time);
            Console.WriteLine("___________________________________________________________________________");
            Console.WriteLine("Описание:",Description);           
            Console.WriteLine("___________________________________________________________________________");
            Console.WriteLine("Номер телефона:",phone_number);
            Console.WriteLine("___________________________________________________________________________");
            Console.WriteLine("email:",email);

        }

































    }
}
