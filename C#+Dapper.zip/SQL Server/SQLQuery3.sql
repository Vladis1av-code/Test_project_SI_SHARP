USE [Mailing_list]
GO

/****** Object:  Table [dbo].[Info_2]    Script Date: 08.07.2024 21:44:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Info](
	[customer_id] [int] NOT NULL,
	[full_name] [varchar](max) NOT NULL,
	[date_of_birth] [date] NOT NULL,
	[buyer_position] [varchar](max) NULL,
	[email] [nvarchar](max) NOT NULL,
	[buyer_country] [varchar](max) NOT NULL,
	[buyer_city] [varchar](max) NOT NULL,
	[sections] [varchar](50) NOT NULL,
	[stock] [nvarchar](max) NOT NULL,
	[quantity][nvarchar](max) NOT NULL,
	[purchase_date][nvarchar](max) NOT NULL
PRIMARY KEY CLUSTERED 
(
	[customer_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


