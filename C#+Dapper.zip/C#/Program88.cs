﻿using System.Data;
using System.Data.SqlClient;
using Dapper;
using System;
using System.IO;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using Microsoft.Identity.Client;
using ConsoleApp36;
 using Microsoft.Data.SqlClient;
namespace ConsoleApp36
{
    public class Users
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string date { get; set; } 
        public string buyer_position {  get; set; }
        public string email {  get; set; }

        public string buyer_country {  get; set; }

        public string buyer_city {  get; set; }
        public string sections {  get; set; }
        public string stock {  get; set; }
        public object quantity { get; internal set; }
        public object purchase_date { get; internal set; }

    }
  

    class Program
    {
        static void Main(string[] args)
        {
            string Sql_Connection = "Data Source=DESKTOP-M09DVFG;Initial Catalog=Mailing_list;Integrated Security=True;";
            
            Console.WriteLine("Меню");
            Console.WriteLine("______________________________________________________________________________________");
            Console.WriteLine("1.Данные для рассылки про акционные товары");
            Console.WriteLine("2.Показать всех покупателей");
            Console.WriteLine("3.Показать Email всех покупателей");
            Console.WriteLine("4.Показать список отделов");
            Console.WriteLine("5.Показать список акций");
            Console.WriteLine("6.Показать все места");
            Console.WriteLine("7.Показать все страны");
            Console.WriteLine("8.Показать всех покупателей с определенного города");
            Console.WriteLine("9.Показать всех покупателей с опеределенной страны");
            Console.WriteLine("10.Показать все акции для определенной страны");
            Console.WriteLine("11.Показать количество городов в каждой стране");
            Console.WriteLine("12.Показать среднее количество городов по всей стране");
            Console.WriteLine("13.Показать все разделы какие нравится клиентам с опреденной страны");
            Console.WriteLine("14.Показать все акции определонного раздела за указаным промежутком времени");
            Console.WriteLine("15.Показать все акции определенного покупателя");
            Console.WriteLine("16.Выход");
            Console.WriteLine("______________________________________________________________________________________");
            Console.Write("Введите цифру:");
            string choice_users = Console.ReadLine();

            if (choice_users == "1")
            {
                Console.Write("Введите Ф.И.О покупателя:");

                string choice_full_name= Console.ReadLine();

                Console.Write("Введите дату рождение покупателя:");

                string choice_date= Console.ReadLine();

                Console.Write("Введите пол покупателя:");

                string choice_gender= Console.ReadLine();

                Console.Write("Введите email покупателя:");

                string choice_email= Console.ReadLine();

                Console.Write("Введите страну покупателя:");

                string choice_nation= Console.ReadLine();

                Console.Write("Введите место покупателя:");

                string choice_city= Console.ReadLine();

                Console.Write("Введите раздел:");

                string choice_sections=Console.ReadLine();

                Console.Write("Введите акции начало старта и конец конца:");

                string choice_stock=Console.ReadLine();

               using(IDbConnection db=new SqlConnection(Sql_Connection))
                {
                    var users = new Users
                    {
                        Name = choice_full_name,
                        date = choice_date,
                        buyer_position = choice_gender,
                        email = choice_email,
                        buyer_country = choice_nation,
                        buyer_city = choice_city,
                        sections = choice_sections,
                        stock = choice_stock
                    };
                    string sql_5 = "INSERT INTO Info (full_name,data_of_birth,buyer_position,email,buyer_country,buyer_city,sections,stock) " +
                        "VALUES(@Name,@date,@buyer_position,@email,@buyer_country,@buyer_city,@sections,@stock)";
                    var add=db.Execute(sql_5, users);
                    if(add>0)
                    {
                        Console.WriteLine("Новая информация успешно была добавлена в базу данных");
                    }
                    else
                    {
                        Console.WriteLine("Извините произошла ошибка при записи в базу данных");
                    }
                }

            }
            else if (choice_users == "2")
            {
             using(IDbConnection db = new SqlConnection(Sql_Connection))
                {
                    string sql = "SELECT * FROM Info";
                    var users=db.Query<Users>(sql).ToList();

                    foreach (var user in users)
                    {
                        Console.WriteLine("__________________________________________________________");
                        Console.WriteLine($"ID пользователя:{user.Id}");
                        Console.WriteLine($"Ф.И.О пользователя:{user.Name}");
                        Console.WriteLine($"Дата рождение пользователя:{user.date}");
                        Console.WriteLine($"Пол пользователя:{user.buyer_position}");
                        Console.WriteLine($"Email пользователя:{user.email}");
                        Console.WriteLine($"Страна пользователя:{user.buyer_country}");
                        Console.WriteLine($"Город пользователя:{user.buyer_city}");
                        Console.WriteLine($"Разделы пользователя:{user.sections}");
                        Console.WriteLine($"Акции пользователя:{user.stock}");
                        Console.WriteLine("__________________________________________________________");
                    }
                }

          
            }
            else if (choice_users == "3")
            {
                using (IDbConnection db = new SqlConnection(Sql_Connection))
                {
                    string sql = "SELECT * full_name,Email";
                    var users = db.Query<Users>(sql).ToList();

                    foreach (var user in users)
                    {
                        Console.WriteLine("__________________________________________________________");
                        Console.WriteLine($"Ф.И.О:{user.Name}");
                        Console.WriteLine($"Email пользователя:{user.email}");
                        Console.WriteLine("__________________________________________________________");
                    }
                }
            }
            else if (choice_users == "4")
            {
                using(IDbConnection db = new SqlConnection( Sql_Connection))
                {
                    string sql_3 = "SELECT * sections";
                    var users=db.Query<Users>(sql_3).ToList();

                    foreach(var user in users)
                    {
                        Console.WriteLine("__________________________________________________________");
                        Console.WriteLine($"Все отделы которые существуют:{user.sections}");
                        Console.WriteLine("__________________________________________________________");
                    }
                }
            }
            else if (choice_users == "5")
            {
                using(IDbConnection db = new SqlConnection(Sql_Connection))
                {
                    string sql_4 = "SELECT * stock";
                    var users=db.Query<Users>(sql_4).ToList();
                    foreach (var user in users)
                    {
                        Console.WriteLine("__________________________________________________________");
                        Console.WriteLine($"Все акции которые существуют:{user.stock}");
                        Console.WriteLine("__________________________________________________________");
                    }
                }
            }
            else if (choice_users == "6")
            {
                using (IDbConnection db = new SqlConnection(Sql_Connection))
                {
                    string sql_1 = "SELECT * buyer_city";
                    var users = db.Query<Users>(sql_1).ToList();

                    foreach (var user in users)
                    {
                        Console.WriteLine("__________________________________________________________");
                        Console.WriteLine($"Город:{user.buyer_city}");               
                        Console.WriteLine("__________________________________________________________");
                    }
                }
            }
            else if (choice_users == "7")
            {
                using (IDbConnection db = new SqlConnection(Sql_Connection))
                {
                    string sql_2 = "SELECT * buyer_country,buyer_city";
                    var users = db.Query<Users>(sql_2).ToList();

                    foreach (var user in users)
                    {
                        Console.WriteLine("__________________________________________________________");
                        Console.WriteLine($"Страна:{user.buyer_country}");
                        Console.WriteLine($"Город:{user.buyer_city}");
                        Console.WriteLine("__________________________________________________________");
                    }
                }
            }
            else if (choice_users == "8")
            {
                Console.WriteLine("Введите город:");
                string choice_city_1=Console.ReadLine();

                using (IDbConnection db = new SqlConnection(Sql_Connection))
                {
                    
                    string sql = "SELECT Id, Name, email, buyer_country, buyer_city FROM Info";

                    // Добавляем условие для фильтрации по городу
                    sql += " WHERE buyer_city = @City";

                    var users = db.Query<Users>(sql, new { City = choice_city_1 }).ToList();

                   
                    if (users.Count > 0)
                    {
                        Console.WriteLine("Найдены следующие покупатели:");
                        foreach (var user in users)
                        {
                            Console.WriteLine($"Имя: {user.Name}, Город: {user.buyer_city}");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Покупателей из города {choice_city_1} не найдено.");
                    }
                }
            }
            else if (choice_users == "9")
            {
                Console.WriteLine("Введите страну:");
                string choice_country_1=Console.ReadLine();
                using (IDbConnection db = new SqlConnection(Sql_Connection))
                {
                    string sql = "SELECT * FROM Info WHERE buyer_country = @buyer_country";

                    var users = db.Query<Users>(sql, new { Country = choice_country_1 }).ToList();

                    if (users.Count > 0)
                    {
                        Console.WriteLine($"Покупатели из страны {choice_country_1}:");
                        foreach (var user in users)
                        {
                            Console.WriteLine($"Имя: {user.Name}, Город: {user.buyer_city}");
                          
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Покупатели из страны {choice_country_1} не найдены.");
                    }
                }
            }
            else if (choice_users == "10")
            {
                Console.Write("Введите страну: ");
                string choice_country_2 = Console.ReadLine();

                using (IDbConnection db = new SqlConnection(Sql_Connection))
                {                 
                    string sql = "SELECT * FROM Info WHERE stock=@stock";

                    var акции = db.Query<Users>(sql, new { Country = choice_country_2 }).ToList();

                    if (акции.Count > 0)
                    {
                        Console.WriteLine($"Акции для страны {choice_country_2}:");
                        foreach (var акция in акции)
                        {
                            Console.WriteLine($"Акция: {акция.stock}, Страна: {акция.buyer_country}");
                        
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Акции для страны {choice_country_2} не найдены.");
                    }
                }
            }
            else if (choice_users == "11")
            {
                using(IDbConnection db = new SqlConnection(Sql_Connection))
                {
                    var citiesByCountry = db.Query<dynamic>("SELECT buyer_country, COUNT(*) AS CityCount FROM Info GROUP BY buyer_country").ToList();
                    Console.WriteLine($"");

                }
            }
            else if (choice_users == "12")
            {
                using (IDbConnection db = new SqlConnection(Sql_Connection))
                {
                    var Cities = db.Query<double>("SELECT AVG(COUNT(*)) FROM (SELECT buyer_country FROM Info GROUP BY buyer_country) AS Counts").Single();
                    Console.WriteLine($"Среднее количество городов: {Cities}");
                }
            }
            else if (choice_users == "13")
            {
                Console.Write("Введите страну: ");
                string choice_country = Console.ReadLine();

                using (IDbConnection db = new SqlConnection(Sql_Connection))
                {
                    // Запрос для подсчета количества 
                    string sql = @"
            SELECT section, COUNT(*) AS total_purchases
            FROM Info
            WHERE section = @section
            GROUP BY section
            ORDER BY total_purchases DESC";

                    var popularSections = db.Query<dynamic>(sql, new { Country = choice_country }).ToList();

                    if (popularSections.Count > 0)
                    {
                        Console.WriteLine($"Самые популярные разделы у клиентов из {choice_country}:");
                        foreach (var section in popularSections)
                        {
                            Console.WriteLine($"Раздел {section.section_id}: {section.total_purchases} покупок");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Нет данных о покупках для страны {choice_country}.");
                    }
                }
            }
            else if (choice_users == "14")
            {
                Console.Write("Введите название раздела: ");
                string choice_section = Console.ReadLine();

                Console.Write("Введите начальную дату (гггг-мм-дд): ");
                DateTime startDate = DateTime.Parse(Console.ReadLine());

                Console.Write("Введите конечную дату (гггг-мм-дд): ");
                DateTime endDate = DateTime.Parse(Console.ReadLine());

                using (IDbConnection db = new SqlConnection(Sql_Connection))
                {
                   
                    string sql = @"
            SELECT *
            FROM Info
            WHERE sections = @Section
              AND date BETWEEN @StartDate AND @EndDate";

                    var акции = db.Query<Users>(sql, new { Section = choice_section, StartDate = startDate, EndDate = endDate }).ToList();

                    if (акции.Count > 0)
                    {
                        Console.WriteLine($"Акции раздела {choice_section} за период с {startDate:yyyy-MM-dd} по {endDate:yyyy-MM-dd}:");
                        foreach (var акция in акции)
                        {
                            Console.WriteLine($"Акция: {акция.stock}, Дата: {акция.date}");                           
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Акции за указанный период не найдены.");
                    }
                }
            }
            else if (choice_users == "15")
            {
                Console.Write("Введите ID покупателя: ");
                int userId = int.Parse(Console.ReadLine());

                using (IDbConnection db = new SqlConnection(Sql_Connection))
                {
                    string sql = "SELECT * FROM Info WHERE customer_id = @cutomer_Id";

                    var purchases = db.Query<Users>(sql, new { UserId = userId }).ToList();

                    if (purchases.Count > 0)
                    {
                        Console.WriteLine($"Акции покупателя с ID {userId}:");
                        foreach (var purchase in purchases)
                        {
                            Console.WriteLine($"Акция: {purchase.stock}, Количество: {purchase.quantity}, Дата покупки: {purchase.purchase_date}");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Акции для покупателя с ID {userId} не найдены.");
                    }
                }

            }
            else if (choice_users == "16")
            {
                Console.WriteLine("Вы успешно вышли с предложения");
                return;
            }
            else
            {
                Console.WriteLine("Ошибка попробуйте еще раз!!!");
                return;

            }
        }
    }

   
}
