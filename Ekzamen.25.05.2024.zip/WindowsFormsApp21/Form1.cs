﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp21
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Копия файла
        private void button1_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                // Показ диалогового окна для выбора файла
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string sourceFilePath = openFileDialog.FileName;
                        //Выбор места копированого файла 
                    using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
                    {
                        if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                        {
                            string destinationFolderPath = folderBrowserDialog.SelectedPath;
                            string destinationFilePath = Path.Combine(destinationFolderPath, Path.GetFileName(sourceFilePath));

                            File.Copy(sourceFilePath, destinationFilePath, overwrite: true);
                            textBox1.Text = destinationFilePath;
                        }
                    }
                }
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                // Установка фильтров для типов файлов, если требуется
                openFileDialog.Filter = "All files (*.*)|*.*";
                openFileDialog.Title = "Select a file to download";

                // Показ диалогового окна для выбора файла
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // Выбор места хранения файла
                    using (SaveFileDialog saveFileDialog = new SaveFileDialog())
                    {
                        saveFileDialog.Filter = "All files (*.*)|*.*";
                        saveFileDialog.Title = "Save the file as";
                        saveFileDialog.FileName = Path.GetFileName(openFileDialog.FileName);

                        // Показ диалогового окна для выбора места хранения
                        if (saveFileDialog.ShowDialog() == DialogResult.OK)
                        {
                            // Копирование файла из оригинального местоположения в новое
                            File.Copy(openFileDialog.FileName, saveFileDialog.FileName, true);

                            // Отображение пути сохранения файла в textBox1
                            textBox1.Text = saveFileDialog.FileName;
                        }
                    }
                }
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
        //Очистка
        private void button3_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }
        //Перезагрузка формы
        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 fr = new Form1();
            fr.Show();
        }
        //Измеряем размер файла в байтах
        private void button5_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // Получаем путь до файла
                    string filePath = openFileDialog.FileName;
                    // Получаем размер в байтах
                    long fileSize = new FileInfo(filePath).Length;
                    // Размер файла
                    textBox1.Text = fileSize.ToString() + " bytes";
                }
            }
        }
        //Цвет фона формы
        private void button6_Click_1(object sender, EventArgs e)
        {
            using (ColorDialog colorDialog = new ColorDialog())
            {
                // Показ диалогового окна для выбора цвета
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    // Изменение цвета фона формы на выбранный пользователем цвет
                    this.BackColor = colorDialog.Color;
                }
            }
        }
    }
}
