﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Security.Cryptography;

namespace Client
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TcpClient client = new TcpClient("127.0.0.1", 12345);
            while (true)
            {
                NetworkStream stream = client.GetStream();
                byte[] data = new byte[256];
                int bytes = stream.Read(data, 0, data.Length);

                string responseData = "No DATA";
                if (bytes > 0)
                {
                    responseData = Encoding.UTF8.GetString(data, 0, bytes);
                }
                Console.WriteLine(responseData);
                Thread.Sleep(1000);
            }
            /*UdpClient client = new UdpClient();
            IPEndPoint remoteEp = new IPEndPoint(IPAddress.Parse("192.168.0.103"), 12345);
            try
            {
                while (true)
                {
                    byte[] requestBytes = Encoding.ASCII.GetBytes("Request for time");
                    client.Send(requestBytes, requestBytes.Length, remoteEp);
                    byte[] receiveBytes = client.Receive(ref remoteEp);
                    string currentTime = Encoding.UTF8.GetString(receiveBytes);
                    Console.WriteLine("Time from server: " + currentTime);
                    Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                client.Close();
            }*/
        }
    }
}
