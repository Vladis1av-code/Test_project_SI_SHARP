﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ServerClock
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TcpListener server = null;
            try
            {
                IPAddress ipAdrr = IPAddress.Any;
                int port = 12345;
                server = new TcpListener(ipAdrr, port);
                server.Start();
                Console.WriteLine("Server started...");
                TcpClient client = server.AcceptTcpClient();
                Console.WriteLine("Connected... ");
                while (true)
                {

                    string response = DateTime.Now.ToString();
                    byte[] responseData = Encoding.UTF8.GetBytes(response);
                    NetworkStream stream = client.GetStream();
                    stream.Write(responseData, 0, responseData.Length);
                    Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
           
            /*UdpClient server = new UdpClient(12345);
            IPEndPoint remoteEp = new IPEndPoint(IPAddress.Any, 0);
            Console.WriteLine("Server Clock started...");
            while (true) 
            {
                byte[] receiveBytes = server.Receive(ref remoteEp);
                string request = Encoding.UTF8.GetString(receiveBytes);
                Console.WriteLine("Received request from client: "+request);
                if (request == "Request for time")
                {
                    string currentTime = DateTime.Now.ToString();
                    byte[] sendBytes = Encoding.UTF8.GetBytes(currentTime);
                    server.Send(sendBytes, sendBytes.Length, remoteEp);
                }
                else
                {
                    Console.WriteLine("Invalid command");
                }
                Thread.Sleep(1000);
            }*/
        }
    }
}
